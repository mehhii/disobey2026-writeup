# Sliceshare

## What?
Sliceshare is new, bleeding edge, state-of-the-art solution to replace
FTP and other file sharing solutions.

## Why?
Because old, tested and robust solutions are Boring and un-marketable.
It's much better to have a new thing to sell, than to keep using
*old* things.

## Where?
sliceshare.divanodivino.xyz:1234 has our latest and extremely secure
instance running.

## Note
This is bleeding edge software, to integrate your solutions
you'll need to ensure you're only using the most recent state-of-the-art
software and libraries as well.